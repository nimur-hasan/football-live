package com.nehalappstudio.footballlive.models

data class TeamCardModel(
    val img: String,
    val name: String,
    val location: String,
    val founded: String
)
