
package com.nehalappstudio.footballlive

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PrivacyPolicy : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy_policy)
    }
}