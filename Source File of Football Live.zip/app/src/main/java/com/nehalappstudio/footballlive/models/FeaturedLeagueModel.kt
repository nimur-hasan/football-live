package com.nehalappstudio.footballlive.models

data class FeaturedLeagueModel(
    val logo:String,
    val name:String,
    val id: String
)
