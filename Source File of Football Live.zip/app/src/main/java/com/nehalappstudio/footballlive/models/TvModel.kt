package com.nehalappstudio.footballlive.models

data class TvModel(
    val id: String,
    val channel_title: String,
    val channel_url: String,
    val channel_thumbnail: String,
)
